import { Component } from '@angular/core';

/**
 * @title Plain Button One Allianz additions
 */
@Component({
    selector: 'button-plain-a1-example',
    templateUrl: './button-plain-a1-example.html',
    styleUrls: ['./button-plain-a1-example.css'],
})
export class ButtonPlainA1ExampleComponent {}
