import { Component } from '@angular/core';

/**
 * @title Light Styling Example
 */
@Component({
    selector: 'accordion-light-example',
    templateUrl: './accordion-light-example.html',
    styleUrls: ['./accordion-light-example.css'],
})
export class AccordionLightExampleComponent {}
