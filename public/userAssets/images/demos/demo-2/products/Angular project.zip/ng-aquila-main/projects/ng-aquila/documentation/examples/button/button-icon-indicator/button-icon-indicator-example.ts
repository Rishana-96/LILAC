import { Component } from '@angular/core';

/**
 * @title Icon button with indicators
 */
@Component({
    selector: 'button-icon-indicator-example',
    templateUrl: './button-icon-indicator-example.html',
    styleUrls: ['./button-icon-indicator-example.css'],
})
export class ButtonIconIndicatorExampleComponent {}
