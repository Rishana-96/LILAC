import { Component } from '@angular/core';

/**
 * @title Formatting example
 */
@Component({
    selector: 'datefield-formatting-example',
    templateUrl: './datefield-formatting-example.html',
    styleUrls: ['./datefield-formatting-example.css'],
})
export class DatefieldFormattingExampleComponent {}
