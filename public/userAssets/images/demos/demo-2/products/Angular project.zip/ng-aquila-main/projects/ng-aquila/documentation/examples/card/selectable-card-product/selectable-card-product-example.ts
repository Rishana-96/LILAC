import { Component } from '@angular/core';

/**
 * @title Selectable cards product example
 */
@Component({
    selector: 'selectable-card-product-example',
    templateUrl: './selectable-card-product-example.html',
    styleUrls: ['./selectable-card-product-example.scss'],
})
export class SelectableCardProductExampleComponent {}
