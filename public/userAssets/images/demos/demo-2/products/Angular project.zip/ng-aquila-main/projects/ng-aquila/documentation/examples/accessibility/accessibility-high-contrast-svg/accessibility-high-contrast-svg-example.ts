import { Component } from '@angular/core';

/**
 * @title High contrast svg example
 */
@Component({
    selector: 'accessibility-high-contrast-svg-example',
    templateUrl: './accessibility-high-contrast-svg-example.html',
    styleUrls: ['./accessibility-high-contrast-svg-example.css'],
})
export class AccessibilityHighContrastSvgExampleComponent {}
