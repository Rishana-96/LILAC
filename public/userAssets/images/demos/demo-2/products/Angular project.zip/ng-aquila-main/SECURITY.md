# Security Policy

## Support version
For information on supported versions and the upgrade process,
Please refer to the [RELEASE.md](projects/ng-aquila/documentation/guides/releases.md) page.

