import { Component } from '@angular/core';

/**
 * @title Large Size Example
 */
@Component({
    selector: 'button-large-example',
    templateUrl: './button-large-example.html',
    styleUrls: ['./button-large-example.css'],
})
export class ButtonLargeExampleComponent {}
