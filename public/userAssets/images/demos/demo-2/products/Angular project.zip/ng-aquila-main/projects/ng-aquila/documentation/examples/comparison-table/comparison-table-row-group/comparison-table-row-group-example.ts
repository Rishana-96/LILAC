import { Component } from '@angular/core';

/** @title Row group example */
@Component({
    selector: 'comparison-table-row-group-example',
    templateUrl: './comparison-table-row-group-example.html',
    styleUrls: ['./comparison-table-row-group-example.css'],
})
export class ComparisonTableRowGroupExampleComponent {}
