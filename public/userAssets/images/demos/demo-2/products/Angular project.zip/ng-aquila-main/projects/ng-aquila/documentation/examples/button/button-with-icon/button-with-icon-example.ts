import { Component } from '@angular/core';

/**
 * @title Icon Example
 */
@Component({
    selector: 'button-with-icon-example',
    templateUrl: './button-with-icon-example.html',
    styleUrls: ['./button-with-icon-example.css'],
})
export class ButtonWithIconExampleComponent {}
