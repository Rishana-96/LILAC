import { Component } from '@angular/core';

/**
 * @title Nested Context Menu Example
 */
@Component({
    selector: 'context-menu-nested-example',
    templateUrl: './context-menu-nested-example.html',
    styleUrls: ['./context-menu-nested-example.css'],
})
export class ContextMenuNestedExampleComponent {}
