import { Component } from '@angular/core';
/**
 * @title Avatar example
 */
@Component({
    selector: 'avatar-example',
    templateUrl: './avatar-example.html',
    styleUrls: ['./avatar-example.css'],
})
export class AvatarExampleComponent {}
