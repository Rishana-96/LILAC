import { Component } from '@angular/core';

/** @title Disabled Columns example */
@Component({
    selector: 'comparison-table-disabled-columns-example',
    templateUrl: './comparison-table-disabled-columns-example.html',
    styleUrls: ['./comparison-table-disabled-columns-example.css'],
})
export class ComparisonTableDisabledColumnsExampleComponent {
    disableColumn = true;
}
