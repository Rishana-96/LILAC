import { Component } from '@angular/core';

/**
 * @title Negative styling example
 */
@Component({
    selector: 'copytext-negative-example',
    templateUrl: './copytext-negative-example.html',
    styleUrls: ['./copytext-negative-example.css'],
})
export class CopytextNegativeExampleComponent {}
