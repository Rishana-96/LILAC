import { Component } from '@angular/core';

/** @title Error example */
@Component({
    selector: 'error-example',
    templateUrl: './error-example.html',
    styleUrls: ['./error-example.css'],
})
export class ErrorExampleComponent {}
