import { Component } from '@angular/core';

/**
 * @title Light Negative Styling Example
 */
@Component({
    selector: 'accordion-light-negative-example',
    templateUrl: './accordion-light-negative-example.html',
    styleUrls: ['./accordion-light-negative-example.css'],
})
export class AccordionLightNegativeExampleComponent {}
