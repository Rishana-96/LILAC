import { Component } from '@angular/core';

/**
 * @title Checkbox group label size example
 */
@Component({
    selector: 'checkbox-group-label-size-example',
    templateUrl: './checkbox-group-label-size-example.html',
    styleUrls: ['./checkbox-group-label-size-example.css'],
})
export class CheckboxGroupLabelSizeExampleComponent {}
