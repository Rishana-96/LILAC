import { Component } from '@angular/core';

/**
 * @title Anchor Button Example
 */
@Component({
    selector: 'anchor-button-example',
    templateUrl: './anchor-button-example.html',
    styleUrls: ['./anchor-button-example.css'],
})
export class AnchorButtonExampleComponent {}
