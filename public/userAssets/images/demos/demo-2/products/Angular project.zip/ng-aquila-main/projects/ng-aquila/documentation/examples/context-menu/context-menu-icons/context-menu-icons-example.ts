import { Component } from '@angular/core';

/**
 * @title Icons Context Menu Example
 */
@Component({
    selector: 'context-menu-icons-example',
    templateUrl: './context-menu-icons-example.html',
    styleUrls: ['./context-menu-icons-example.css'],
})
export class ContextMenuIconsExampleComponent {}
