import { Component } from '@angular/core';

/**
 * @title Basic formfield example
 */
@Component({
    selector: 'formfield-basic-example',
    templateUrl: './formfield-basic-example.html',
    styleUrls: ['./formfield-basic-example.css'],
})
export class FormfieldBasicExampleComponent {}
