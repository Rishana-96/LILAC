import { Component } from '@angular/core';

/**
 * @title Character count example
 */
@Component({
    selector: 'formfield-character-count-example',
    templateUrl: './formfield-character-count-example.html',
    styleUrls: ['./formfield-character-count-example.css'],
})
export class FormfieldCharacterCountExampleComponent {}
