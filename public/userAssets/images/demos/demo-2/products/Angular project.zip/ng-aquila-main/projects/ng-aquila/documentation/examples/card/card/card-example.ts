import { Component } from '@angular/core';

/**
 * @title Default Card Example
 */
@Component({
    selector: 'card-example',
    templateUrl: './card-example.html',
    styleUrls: ['./card-example.css'],
})
export class CardExampleComponent {}
