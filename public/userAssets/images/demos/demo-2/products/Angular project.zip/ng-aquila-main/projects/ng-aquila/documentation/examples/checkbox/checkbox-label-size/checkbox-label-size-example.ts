import { Component } from '@angular/core';

/**
 * @title Label size example
 */
@Component({
    selector: 'checkbox-label-size-example',
    templateUrl: './checkbox-label-size-example.html',
    styleUrls: ['./checkbox-label-size-example.css'],
})
export class CheckboxLabelSizeExampleComponent {}
