import { Component } from '@angular/core';

/**
 * @title Cursor Mode Context Menu Example
 */
@Component({
    selector: 'context-menu-cursor-mode-example',
    templateUrl: './context-menu-cursor-mode-example.html',
    styleUrls: ['./context-menu-cursor-mode-example.css'],
})
export class ContextMenuCursorModeExampleComponent {}
