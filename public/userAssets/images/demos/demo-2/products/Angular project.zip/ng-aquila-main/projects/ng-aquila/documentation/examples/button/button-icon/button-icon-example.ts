import { Component } from '@angular/core';

/**
 * @title Icon Button Example
 */
@Component({
    selector: 'button-icon-example',
    templateUrl: './button-icon-example.html',
    styleUrls: ['./button-icon-example.css'],
})
export class ButtonIconExampleComponent {}
