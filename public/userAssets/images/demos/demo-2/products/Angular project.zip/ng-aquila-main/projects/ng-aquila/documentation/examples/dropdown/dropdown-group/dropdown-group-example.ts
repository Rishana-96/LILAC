import { Component } from '@angular/core';

/**
 * @title Dropdown group example
 */
@Component({
    selector: 'dropdown-group-example',
    templateUrl: './dropdown-group-example.html',
    styleUrls: ['./dropdown-group-example.css'],
})
export class DropdownGroupExampleComponent {
    testBind = 'Catfish';
}
