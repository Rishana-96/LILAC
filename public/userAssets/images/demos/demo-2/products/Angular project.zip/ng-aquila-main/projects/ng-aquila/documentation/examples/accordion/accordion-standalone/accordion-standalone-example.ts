import { Component } from '@angular/core';

/**
 * @title Standalone Expansion Panel Example
 */
@Component({
    selector: 'accordion-standalone-example',
    templateUrl: './accordion-standalone-example.html',
    styleUrls: ['./accordion-standalone-example.css'],
})
export class AccordionStandaloneExampleComponent {}
