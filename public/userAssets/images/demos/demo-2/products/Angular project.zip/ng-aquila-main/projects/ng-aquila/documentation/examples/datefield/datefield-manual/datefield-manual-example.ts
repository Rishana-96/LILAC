import { Component } from '@angular/core';
/**
 * @title Manual control example
 */
@Component({
    selector: 'datefield-manual-example',
    templateUrl: './datefield-manual-example.html',
    styleUrls: ['./datefield-manual-example.css'],
})
export class DatefieldManualExampleComponent {}
