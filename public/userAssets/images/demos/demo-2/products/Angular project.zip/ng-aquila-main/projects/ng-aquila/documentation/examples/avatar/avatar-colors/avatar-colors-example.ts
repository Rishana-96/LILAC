import { Component } from '@angular/core';
/**
 * @title Colors example
 */
@Component({
    selector: 'avatar-colors-example',
    templateUrl: './avatar-colors-example.html',
    styleUrls: ['./avatar-colors-example.css'],
})
export class AvatarColorsExampleComponent {}
