import { Component } from '@angular/core';

/**
 * @title Disabled example
 */
@Component({
    selector: 'datefield-disabled-example',
    templateUrl: './datefield-disabled-example.html',
    styleUrls: ['./datefield-disabled-example.css'],
})
export class DatefieldDisabledExampleComponent {}
