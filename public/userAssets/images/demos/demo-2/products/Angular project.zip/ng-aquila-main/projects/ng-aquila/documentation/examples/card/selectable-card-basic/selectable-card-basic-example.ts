import { Component } from '@angular/core';

/**
 * @title Selectable cards basic example
 */
@Component({
    selector: 'selectable-card-basic-example',
    templateUrl: './selectable-card-basic-example.html',
    styleUrls: ['./selectable-card-basic-example.scss'],
})
export class SelectableCardBasicExampleComponent {}
