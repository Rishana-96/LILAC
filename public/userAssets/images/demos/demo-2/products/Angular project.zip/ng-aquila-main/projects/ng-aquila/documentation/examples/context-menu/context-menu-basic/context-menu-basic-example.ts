import { Component } from '@angular/core';

/**
 * @title Basic Context Menu Example
 */
@Component({
    selector: 'context-menu-basic-example',
    templateUrl: './context-menu-basic-example.html',
    styleUrls: ['./context-menu-basic-example.css'],
})
export class ContextMenuBasicExampleComponent {}
