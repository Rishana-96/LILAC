import { Component } from '@angular/core';

/**
 * @title Disabled Context Menu Example
 */
@Component({
    selector: 'context-menu-disabled-example',
    templateUrl: './context-menu-disabled-example.html',
    styleUrls: ['./context-menu-disabled-example.css'],
})
export class ContextMenuDisabledExampleComponent {}
