import { Component } from '@angular/core';

/**
 * @title Selectable cards states example
 */
@Component({
    selector: 'highlight-selectable-card-example',
    templateUrl: './highlight-selectable-card-example.html',
    styleUrls: ['./highlight-selectable-card-example.css'],
})
export class HighlightSelectableCardExampleComponent {}
