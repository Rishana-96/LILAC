import { Component } from '@angular/core';

/**
 * @title Footer default copyright
 */
@Component({
    selector: 'footer-default-copyright-example',
    templateUrl: './footer-default-copyright-example.html',
    styleUrls: ['footer-default-copyright-example.css'],
})
export class FooterDefaultCopyrightExampleComponent {}
