import { Component } from '@angular/core';

/**
 * @title Lazy Loading Example
 */
@Component({
    selector: 'accordion-lazy-example',
    templateUrl: './accordion-lazy-example.html',
    styleUrls: ['./accordion-lazy-example.css'],
})
export class AccordionLazyExampleComponent {}
