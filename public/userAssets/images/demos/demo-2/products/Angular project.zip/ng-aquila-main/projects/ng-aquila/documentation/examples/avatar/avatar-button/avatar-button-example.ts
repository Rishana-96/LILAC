import { Component } from '@angular/core';
/**
 * @title Button example
 */
@Component({
    selector: 'avatar-button-example',
    templateUrl: './avatar-button-example.html',
    styleUrls: ['./avatar-button-example.css'],
})
export class AvatarButtonExampleComponent {}
