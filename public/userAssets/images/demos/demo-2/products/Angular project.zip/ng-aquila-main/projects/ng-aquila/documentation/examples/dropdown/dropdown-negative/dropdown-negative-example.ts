import { Component } from '@angular/core';

/**
 * @title Negative styling example
 */
@Component({
    selector: 'dropdown-negative-example',
    templateUrl: './dropdown-negative-example.html',
    styleUrls: ['./dropdown-negative-example.css'],
})
export class DropdownNegativeExampleComponent {}
