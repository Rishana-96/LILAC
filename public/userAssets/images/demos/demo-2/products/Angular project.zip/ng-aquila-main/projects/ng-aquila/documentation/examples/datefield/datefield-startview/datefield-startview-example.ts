import { Component } from '@angular/core';
/**
 * @title Start view example
 */
@Component({
    selector: 'datefield-startview-example',
    templateUrl: './datefield-startview-example.html',
    styleUrls: ['./datefield-startview-example.css'],
})
export class DatefieldStartviewExampleComponent {}
