This Angular library includes code from the following third parties:

## Angular Material (MIT License) - https://github.com/angular/material2

-   Naming conventions
-   Contribution guidelines
-   Datepicker
-   Form fields
-   Input
-   Tabs
-   Smaller additions
-   Context Menu
-   ng add schematics
-   FocusTrap

## Clarity (MIT License) - https://github.com/vmware/clarity

-   Parts of the clarity viewer

## parse5-traverse (MIT License) - https://github.com/JPeer264/parse5-traverse

-   Logic for tree traversing (AST)

## Egg.js (MIT License) - https://github.com/mikeflynn/egg.js

-   Add eastereggs to the documentation viewer

## Nebular (MIT License) - https://github.com/akveo/nebular

-   Theming
-   Parts of icon registry

## Unsplash (License: https://unsplash.com/license) - https://unsplash.com/

-   Add Photos from various artists to the image documentation

## scrollparent.js (MIT License) - https://github.com/olahol/scrollparent.js

-   Determine the scrolling parent of a container
