import { Component } from '@angular/core';

/** @title Expert: Use full row for Expandable area */
@Component({
    selector: 'comparison-table-expandable-area-example',
    templateUrl: './comparison-table-expandable-area-example.html',
    styleUrls: ['./comparison-table-expandable-area-example.css'],
})
export class ComparisonTableExpandableAreaExampleComponent {}
