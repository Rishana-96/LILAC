import { Component } from '@angular/core';

/**
 * @title Plain Buttons Example
 */
@Component({
    selector: 'button-plain-example',
    templateUrl: './button-plain-example.html',
    styleUrls: ['./button-plain-example.css'],
})
export class ButtonPlainExampleComponent {}
