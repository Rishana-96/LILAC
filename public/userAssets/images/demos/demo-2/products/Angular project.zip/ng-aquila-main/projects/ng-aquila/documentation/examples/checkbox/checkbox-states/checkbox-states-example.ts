import { Component } from '@angular/core';

/**
 * @title Checkbox States
 */
@Component({
    selector: 'checkbox-states-example',
    templateUrl: './checkbox-states-example.html',
    styleUrls: ['./checkbox-states-example.css'],
})
export class CheckboxStatesExampleComponent {}
