import { Component } from '@angular/core';

/**
 * @title Highlight Card Example
 */
@Component({
    selector: 'highlight-card-example',
    templateUrl: './highlight-card-example.html',
    styleUrls: ['./highlight-card-example.css'],
})
export class HighlightCardExampleComponent {}
