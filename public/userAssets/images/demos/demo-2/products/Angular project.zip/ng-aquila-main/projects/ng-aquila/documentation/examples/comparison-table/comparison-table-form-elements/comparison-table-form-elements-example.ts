import { Component } from '@angular/core';

/** @title Add custom form elements to the table */
@Component({
    selector: 'comparison-table-form-elements-example',
    templateUrl: './comparison-table-form-elements-example.html',
    styleUrls: ['./comparison-table-form-elements-example.css'],
})
export class ComparisonTableFormElementsExampleComponent {}
