import { Component } from '@angular/core';

/**
 * @title Standard data display example
 */
@Component({
    selector: 'data-display-standard-example',
    templateUrl: './data-display-standard-example.html',
    styleUrls: ['./data-display-standard-example.css'],
})
export class DataDisplayStandardExampleComponent {}
