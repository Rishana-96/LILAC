import { Component } from '@angular/core';

/**
 * @title Scroll Strategy Context Menu Example
 */
@Component({
    selector: 'context-menu-scroll-strategy-example',
    templateUrl: './context-menu-scroll-strategy-example.html',
    styleUrls: ['./context-menu-scroll-strategy-example.css'],
})
export class ContextMenuScrollStrategyExampleComponent {}
